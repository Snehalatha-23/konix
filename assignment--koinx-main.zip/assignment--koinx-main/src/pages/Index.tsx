
import { TaxLossHarvesting } from "@/components/tax-loss-harvesting/TaxLossHarvesting";

const Index = () => {
  return (
    <div className="bg-gray-50 min-h-screen">
      <TaxLossHarvesting />
    </div>
  );
};

export default Index;
